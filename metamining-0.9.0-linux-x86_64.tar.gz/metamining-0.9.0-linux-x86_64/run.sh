#!/usr/bin/env bash
# MetaMining 0.9.0 portable launcher (args pass through to the server).
cd "$(dirname "$0")"
export LD_LIBRARY_PATH="$PWD/lib:${LD_LIBRARY_PATH:-}"
exec ./metamining "$@"
