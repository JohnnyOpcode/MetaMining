MetaMining 0.9.0 (linux x86_64, portable bundle)
================================================
Run:   ./run.sh            # serves http://127.0.0.1:8000
       ./run.sh --help     # all flags
Live:  META_API_KEY=... ./run.sh --endpoint https://api.meta.ai/v1 --model <id>
Docs:  https://github.com/JohnnyOpcode/MetaMining (docs/quickstart.md)
License: AGPL-3.0-only
Needs: glibc + libssl.so.3 / libcrypto.so.3 (Debian/Ubuntu: apt install libssl3).
Mojo runtime libs ship in lib/ — keep them next to the binary.
